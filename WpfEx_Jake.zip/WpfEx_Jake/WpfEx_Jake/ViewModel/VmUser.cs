﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using WpfEx_Jake.Interface;
using WpfEx_Jake.Model;

namespace WpfEx_Jake.ViewModel
{
    public class VmUser : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged([CallerMemberName] string propName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));

        private long _Idx;
        public long Idx
        {
            get => _Idx;
            set
            {
                if(_Idx != value)
                {
                    _Idx = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _Name;
        public string Name
        {
            get => _Name;
            set
            {
                if (_Name != value)
                {
                    _Name = value;
                    RaisePropertyChanged();
                }
            }
        }

        private int _Age;
        public int Age
        {
            get => _Age;
            set
            {
                if (_Age != value)
                {
                    _Age = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _PhoneNum;
        public string PhoneNum
        {
            get => _PhoneNum;
            set
            {
                if (_PhoneNum != value)
                {
                    _PhoneNum = value;
                    RaisePropertyChanged();
                }
            }
        }
    }
}
