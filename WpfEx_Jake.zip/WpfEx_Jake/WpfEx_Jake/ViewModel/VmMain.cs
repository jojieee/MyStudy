﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfEx_Jake.Interface;
using WpfEx_Jake.Model;

namespace WpfEx_Jake.ViewModel
{
    public class VmMain : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged([CallerMemberName] string propName = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));

        private IAddressBookManager addrbookManager => this.GetContainer().Resolve<IAddressBookManager>();

        private string _DataName;
        public string DataName
        {
            get => _DataName;
            set
            {
                if(_DataName != value)
                {
                    _DataName = value;
                    RaisePropertyChanged();
                }
            }
        }

        private ObservableCollection<VmUser> _Users = new ObservableCollection<VmUser>();
        public ObservableCollection<VmUser> Users
        {
            get => _Users;
            set
            {
                if (_Users != value)
                {
                    _Users = value;
                    RaisePropertyChanged();
                }
            }
        }
 

        public ICommand MyCommand { get; set; }

        public VmMain()
        {
            if (addrbookManager.LoadData())
            {
                SetAddrBookData(addrbookManager.AddrBook);
                MyCommand = new Command(ExecuteMethod, CanExcuteMethod);
            }
        }

        private void ExecuteMethod(object obj)
        {
            SetAddrBookData(addrbookManager.AddrBook);
            MessageBox.Show("불러와라");
            
        }

        private bool CanExcuteMethod(object arg)
        {
            return true;
        }

        private void SetAddrBookData(AddressBook addrBook)
        {

            if(addrBook != null)
            {
                DataName = addrBook.BookName;
                if (addrBook.Users != null)
                {
                    var tmpUsers = from user in addrBook.Users
                                   select new VmUser()
                                   {
                                       Idx = user.Idx,
                                       Name = user.Name,
                                       Age = user.Age,
                                       PhoneNum = user.PhoneNum
                                   };
                    Users = new ObservableCollection<VmUser>(tmpUsers);
                }
            }
        }

        
        
    }
}
