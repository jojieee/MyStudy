﻿namespace WpfEx_Jake.Interface
{
    public enum SerializerType
    {
        JSON,
        XML
    }
}