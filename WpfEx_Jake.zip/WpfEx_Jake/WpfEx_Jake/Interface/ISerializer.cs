﻿namespace WpfEx_Jake.Interface
{
    public interface ISerializer
    {
        string Extention { get; }
        bool Serialize(object serializeObj, out string serializedData);
        bool Deserialize<T>(string deserializeData, out T deserializeObj);
    }
}