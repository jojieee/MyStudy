﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfEx_Jake.Model;

namespace WpfEx_Jake.Interface
{
    public interface IAddressBookManager
    {
        AddressBook AddrBook { get; }
        bool LoadData();
        bool SaveData();
    }
}
