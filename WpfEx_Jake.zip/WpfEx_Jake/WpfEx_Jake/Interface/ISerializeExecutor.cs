﻿namespace WpfEx_Jake.Interface
{
    public interface ISerializeExecutor
    {
        ISerializer Serializer { get; }
        bool Serialize(string path, object serializeObj);
        bool Deserialize<T>(string path, out T deserializeObj);
    }
}