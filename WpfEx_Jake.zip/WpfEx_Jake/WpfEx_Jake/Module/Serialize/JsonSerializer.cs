﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using WpfEx_Jake.Interface;

namespace WpfEx_Jake.Module.Serialize
{
    public class JsonSerializer : ISerializer
    {
        public string Extention => "json";

        public bool Serialize(object serializeObj, out string serializedData)
        {
            bool retVal;
            serializedData = string.Empty;

            try
            {
                if (serializeObj != null)
                {
                    serializedData = JsonConvert.SerializeObject(serializeObj, Formatting.Indented);
                    retVal = true;
                }
                else
                {
                    retVal = false;
                    Trace.WriteLine($"직렬화 할 데이터가 비어있습니다.");
                }
            }
            catch (Exception exc)
            {
                retVal = false;
                Trace.WriteLine(exc);
            }

            return retVal;
        }

        public bool Deserialize<T>(string deserializeData, out T deserializeObj)
        {
            bool retVal;

            try
            {
                deserializeObj = JsonConvert.DeserializeObject<T>(deserializeData);
                retVal = true;
            }
            catch (Exception exc)
            {
                deserializeObj = default(T);
                retVal = false;
                Trace.WriteLine(exc);
            }

            return retVal;
        }
    }
}
