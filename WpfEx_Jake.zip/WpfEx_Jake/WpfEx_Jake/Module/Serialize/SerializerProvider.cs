﻿using System;
using System.Diagnostics;
using WpfEx_Jake.Interface;

namespace WpfEx_Jake.Module.Serialize
{
    public static class SerializerProvider
    {
        public static ISerializer GetSerializer(SerializerType serializerType)
        {
            ISerializer serializer = null;

            try
            {
                if(serializerType == SerializerType.JSON)
                {
                    serializer = new JsonSerializer();
                }
                else if (serializerType == SerializerType.XML)
                {
                    serializer = new XmlSerializer();
                }
                else 
                {
                    serializer = new JsonSerializer();
                }
            }
            catch (Exception exc)
            {
                Trace.WriteLine(exc);
            }

            return serializer;
        }
    }
}
