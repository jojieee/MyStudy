﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using WpfEx_Jake.Interface;

namespace WpfEx_Jake.Module.Serialize
{
    public class SerializeExecutor : ISerializeExecutor
    {
        public ISerializer Serializer { get; private set; }
        
        public SerializeExecutor()
        {
            Serializer = SerializerProvider.GetSerializer(SerializerType.JSON);
        }

        public SerializeExecutor(ISerializer _serializer)
        {
            Serializer = _serializer;
        }

        public SerializeExecutor(SerializerType serializertype)
        {
            Serializer = SerializerProvider.GetSerializer(serializertype);
        }

        public bool Serialize(string path, object serializeObj)
        {
            bool retVal;

            try
            {
                if (serializeObj != null && !string.IsNullOrEmpty(path))
                {
                    retVal = SerializeToFile(path, serializeObj);
                }
                else
                {
                    retVal = false;
                    Trace.WriteLine($"직렬화 할 매개변수가 잘못 되었습니다.(path = {path}, object = {serializeObj?.GetType().ToString() ?? "NULL"})");
                }
            }
            catch (Exception exc)
            {
                retVal = false;
                Trace.WriteLine(exc);
            }

            return retVal;
        }

        private bool SerializeToFile(string path, object serializeObj)
        {
            bool retVal;

            try
            {
                if (!Directory.Exists(Directory.GetDirectoryRoot(path)))
                {
                    Directory.CreateDirectory(Directory.GetDirectoryRoot(path));
                }

                if (string.IsNullOrEmpty(Path.GetFileName(path))
                    || string.IsNullOrEmpty(Path.GetExtension(path)))
                {
                    path = Path.Combine(path, $"{serializeObj.GetType().Name}.{Serializer.Extention}");
                }

                if(Serializer.Serialize(serializeObj, out string serializedData))
                {
                    File.WriteAllText(path, serializedData);
                    retVal = true;
                }
                else
                {
                    retVal = false;
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }

            return retVal;
        }

        public bool Deserialize<T>(string path, out T deserializeObj)
        {
            bool retVal;

            try
            {
                retVal = GetObjUsingFileData(path, out deserializeObj);
            }
            catch (Exception exc)
            {
                deserializeObj = default(T);
                retVal = false;
                Trace.WriteLine(exc);
            }

            return retVal;
        }

        private bool GetObjUsingFileData<T>(string path, out T deserializeObj)
        {
            bool retVal;
            deserializeObj = default(T);

            try
            {
                if (!string.IsNullOrEmpty(path))
                {
                    if (string.IsNullOrEmpty(Path.GetFileName(path))
                        || string.IsNullOrEmpty(Path.GetExtension(path)))
                    {
                        path = Path.Combine(path, $"{typeof(T).Name}.{Serializer.Extention}");
                    }

                    if(!File.Exists(path))
                    {
                        var tmpInstance = Activator.CreateInstance<T>();
                        retVal = this.Serialize(path, tmpInstance);
                    }

                    if (File.Exists(path))
                    {
                        string strFileData = File.ReadAllText(path, Encoding.UTF8);
                        retVal = StrToDeserializeObj(strFileData, out deserializeObj);
                    }
                    else
                    {
                        retVal = false;
                    }
                }
                else
                {
                    Trace.WriteLine($"역직렬화 할 대상(파일)이 존재하지 않습니다.(path = {path})");
                    retVal = false;
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }

            return retVal;
        }

        private bool StrToDeserializeObj<T>(string strFileData, out T deserializeObj)
        {
            bool retVal;

            try
            {
                if (!string.IsNullOrEmpty(strFileData))
                {
                    retVal = Serializer.Deserialize(strFileData, out deserializeObj);
                }
                else
                {
                    Trace.WriteLine($"파일로부터 역직렬화한 데이터가 비었습니다.");
                    deserializeObj = default(T);
                    retVal = false;
                }
            }
            catch (Exception exc)
            {
                throw exc;
            }

            return retVal;
        }
    }
}
