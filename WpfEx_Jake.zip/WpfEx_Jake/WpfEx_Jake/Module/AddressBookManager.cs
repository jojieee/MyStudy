﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfEx_Jake.Interface;
using WpfEx_Jake.Model;
using WpfEx_Jake.Module.Serialize;

namespace WpfEx_Jake.Module
{
    public class AddressBookManager : IAddressBookManager
    {
        public string AddressBookFilePath { get => "../../ExData/AddressBook.json"; }
        public AddressBook AddrBook { get; set; }

        public AddressBookManager()
        {
            AddrBook = new AddressBook();
        }

        public bool LoadData()
        {
            bool retVal;
            try
            {
                ISerializeExecutor executor = new SerializeExecutor(SerializerType.JSON);
                retVal = executor.Deserialize(AddressBookFilePath, out AddressBook tmpAddrBook);
                if(retVal)
                {
                    AddrBook = tmpAddrBook;
                }
            }
            catch (Exception exc)
            {
                retVal = false;
                Trace.WriteLine(exc);
            }
            return retVal;
        }

        public bool SaveData()
        {
            bool retVal = false;
            try
            {
                ISerializeExecutor executor = new SerializeExecutor(SerializerType.JSON);
                retVal = executor.Serialize(AddressBookFilePath, AddrBook);
            }
            catch (Exception exc)
            {
                retVal = false;
                Trace.WriteLine(exc);
            }
            return retVal;
        }

    }

    public class Command : ICommand
    {
        Action<object> _executeMethod;
        Func<object, bool> _canexecuteMethod;

        public Command(Action<object> executeMethod, Func<object, bool> canexecuteMethod)
        {
            this._executeMethod = executeMethod;
            this._canexecuteMethod = canexecuteMethod;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _executeMethod(parameter);
        }
    }
}
