﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfEx_Jake.Interface;
using WpfEx_Jake.Model;
using WpfEx_Jake.Module;
using WpfEx_Jake.Module.Serialize;
using WpfEx_Jake.ViewModel;

namespace WpfEx_Jake
{
    public partial class MainWindow : Window
    {
        private IContainer Container;

        public MainWindow()
        {
            ContainerBuilder builder = new ContainerBuilder();

            builder.RegisterType<AddressBookManager>().As<IAddressBookManager>().SingleInstance();

            Container = builder.Build();
            CommonData.SetContainer(Container);

            InitializeComponent();

            this.DataContext = new VmMain();
            #region => ExData Sample (주석)
            //string path = @"..\..\ExData";
            //SerializeExecutor serializeEx = new SerializeExecutor(Interface.SerializerType.JSON);

            //AddressBook addrBook = new AddressBook();
            //addrBook.BookName = "비상연락망";

            //User user = null;
            //user = new User()
            //{
            //    Idx = 211013,
            //    Name = "JAKE",
            //    age = 0,
            //    Company = "YLP",
            //    Description = "TEST0",
            //    EMail = "test0@test.co.kr",
            //    PhoneNum = "000-0000-0000"
            //};
            //user = new User()
            //{
            //    Idx = 200110,
            //    Name = "MAY",
            //    age = 1,
            //    Company = "YLP",
            //    Description = "TEST1",
            //    EMail = "test1@test.co.kr",
            //    PhoneNum = "111-1111-1111"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 191230,
            //    Name = "JUN",
            //    age = 2,
            //    Company = "YLP",
            //    Description = "TEST2",
            //    EMail = "test2@test.co.kr",
            //    PhoneNum = "222-2222-2222"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 910505,
            //    Name = "K",
            //    age = 3,
            //    Company = "YLP",
            //    Description = "TEST3",
            //    EMail = "test3@test.co.kr",
            //    PhoneNum = "333-3333-3333"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 810217,
            //    Name = "Steven",
            //    age = 4,
            //    Company = "YLP",
            //    Description = "TEST4",
            //    EMail = "test4@test.co.kr",
            //    PhoneNum = "444-4444-4444"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 950728,
            //    Name = "Mario",
            //    age = 5,
            //    Company = "YLP",
            //    Description = "TEST5",
            //    EMail = "test5@test.co.kr",
            //    PhoneNum = "555-5555-5555"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 101212,
            //    Name = "Tomas",
            //    age = 6,
            //    Company = "YLP",
            //    Description = "TEST6",
            //    EMail = "test6@test.co.kr",
            //    PhoneNum = "666-6666-6666"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 110830,
            //    Name = "Lou",
            //    age = 7,
            //    Company = "YLP",
            //    Description = "TEST7",
            //    EMail = "test7@test.co.kr",
            //    PhoneNum = "777-7777-7777"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 040226,
            //    Name = "Julia",
            //    age = 8,
            //    Company = "YLP",
            //    Description = "TEST8",
            //    EMail = "test8@test.co.kr",
            //    PhoneNum = "888-8888-8888"
            //};
            //addrBook.Users.Add(user);
            //user = new User()
            //{
            //    Idx = 210927,
            //    Name = "Natalie",
            //    age = 9,
            //    Company = "YLP",
            //    Description = "TEST9",
            //    EMail = "test9@test.co.kr",
            //    PhoneNum = "999-9999-9999"
            //};
            //addrBook.Users.Add(user);

            //if (serializeEx.Serialize(path, addrBook))
            //{
            //    MessageBox.Show("성공");
            //}
            //else
            //{
            //    MessageBox.Show("실패");
            //}

            //if (serializeEx.Deserialize<AddressBook>(path, out AddressBook outAddrBook))
            //{
            //    MessageBox.Show("성공");
            //}
            //else
            //{
            //    MessageBox.Show("실패");
            //}
            #endregion
        }
    }

    public static class CommonData
    {
        private static IContainer Container;
        public static void SetContainer(IContainer container)
        {
            Container = container;
        }

        public static IContainer GetContainer(this object obj)
         => Container;
    }
}
