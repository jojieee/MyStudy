﻿namespace WpfEx_Jake.Model
{
    public class User
    {
        public long Idx { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string PhoneNum { get; set; }
        public string EMail { get; set; }
        public string Company { get; set; }
        public string Description { get; set; }
    }
}