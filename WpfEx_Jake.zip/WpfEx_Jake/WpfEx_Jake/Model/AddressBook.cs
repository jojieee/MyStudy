﻿using System.Collections.Generic;

namespace WpfEx_Jake.Model
{
    public class AddressBook
    {
        public string BookName { get; set; }
        public List<User> Users { get; set; }

        public AddressBook()
        {
            BookName = string.Empty;
            Users = new List<User>();
        }
    }
}